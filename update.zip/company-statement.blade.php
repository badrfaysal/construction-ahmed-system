@extends('layouts.app')
@section('title', 'كشف حساب الشركة: ' . $project->name)
@section('page-title', 'كشف حساب الشركة')

@section('content')
<div class="page-head no-print">
  <div><h3>كشف حساب الشركة (التكلفة) — {{ $project->name }}</h3><p>{{ $project->client->name }} · تكلفة كل بند وكل عملية شراء</p></div>
  <div class="btn-row">
    <button onclick="window.print()" class="btn">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><use href="#i-doc"/></svg>
      طباعة / حفظ PDF
    </button>
    <a href="{{ route('projects.show', $project) }}" class="btn ghost">رجوع</a>
  </div>
</div>

<div class="statement">
  <div class="st-head">
    <div class="co">
      <div class="logo"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><use href="#i-building"/></svg></div>
      <h2>{{ $settings->company_name }}</h2>
      <p>{{ $settings->company_tagline }} @if($settings->company_phone)· هاتف {{ $settings->company_phone }}@endif</p>
    </div>
    <div class="meta">
      <b>كشف حساب الشركة — داخلي</b><br>
      المشروع: {{ $project->name }}<br>
      التاريخ: {{ now()->format('d/m/Y') }}
    </div>
  </div>

  <div class="st-body">
    <div class="st-client">
      <div><div class="l">المشروع</div><div class="b">{{ $project->name }}</div></div>
      <div><div class="l">العميل</div><div class="b">{{ $project->client->name }}</div></div>
      <div><div class="l">عدد البنود</div><div class="b">{{ $project->bands->count() }}</div></div>
    </div>

    {{-- Project summary --}}
    <div class="st-summary">
      <div class="st-box tot"><div class="l">إجمالي التكلفة</div><div class="v">{{ \App\Support\Money::format($totalCost) }} ج.م</div></div>
      <div class="st-box"><div class="l">المفوتر على العميل</div><div class="v">{{ \App\Support\Money::format($totalBilled) }} ج.م</div></div>
      <div class="st-box paid"><div class="l">المحصّل</div><div class="v">{{ \App\Support\Money::format($totalCollected) }} ج.م</div></div>
      @php $totalDisc = $project->totalDiscount(); @endphp
      @if($totalDisc > 0)
        <div class="st-box" style="color:var(--amber)"><div class="l">الخصم الممنوح</div><div class="v" style="color:var(--amber)">{{ \App\Support\Money::format($totalDisc) }} ج.م</div></div>
      @endif
      <div class="st-box {{ $totalProfit >= 0 ? 'paid' : 'due' }}"><div class="l">الربح</div><div class="v">{{ \App\Support\Money::format($totalProfit) }} ج.م</div></div>
    </div>

    @foreach($project->bands as $band)
      @php
        $bMaterialCost = $band->materialCost();
        $bLaborCost    = (float) $band->labor_amount;
        $bTotalCost    = $band->totalCost();
        $bProfit       = $band->profit();
      @endphp

      <div class="st-sec" style="margin-top:22px;background:var(--bg-soft, #f4f6fa)">
        بند: {{ $band->name }}
        <span class="muted" style="font-weight:400">— تكلفة {{ \App\Support\Money::format($bTotalCost) }} ج.م · ربح {{ \App\Support\Money::format($bProfit) }} ج.م</span>
      </div>

      {{-- Purchases (materials + misc expenses) --}}
      <table class="st-table">
        <thead><tr><th>التاريخ</th><th>البيان</th><th>المورد</th><th class="num">الكمية</th><th class="num">سعر الشراء</th><th class="num">التكلفة</th><th class="num">سعر البيع</th><th class="num">إشراف %</th><th class="num">إشراف (ج.م)</th></tr></thead>
        <tbody>
          @php
            $realMaterials = $band->materials->where('category', '!=', 'misc')->sortBy('date');
            $subBands = $band->materials->where('category', 'misc')->sortBy('date');
          @endphp

          {{-- Real Materials --}}
          @if($realMaterials->isNotEmpty())
            <tr><td colspan="9" style="background:var(--bg);font-weight:600;font-size:0.85em;color:var(--text-muted);padding-right:20px;">الخامات</td></tr>
            @foreach($realMaterials as $m)
              <tr>
                <td>{{ $m->date->format('Y-m-d') }}</td>
                <td>
                  {{ $m->item }}
                  @if($m->returnedQty() > 0)<span style="color:var(--neg);font-size:10.5px">(مرتجع {{ \App\Support\Money::format($m->returnedQty(), 1) }})</span>@endif
                </td>
                <td class="muted">{{ $m->supplier?->name ?? $m->supplier_name ?? '—' }}</td>
                <td class="num">{{ \App\Support\Money::format($m->netQty(), 1) . ' ' . $m->unit }}</td>
                <td class="num">{{ \App\Support\Money::format($m->unit_price) }}</td>
                <td class="num"><b>{{ \App\Support\Money::format($m->netCost()) }}</b></td>
                <td class="num">{{ \App\Support\Money::format($m->netQty() * (float)($m->sell_price ?? $m->unit_price)) }}</td>
                <td class="num">{{ (float) $m->supervision_pct }}%</td>
                <td class="num" style="color:var(--pos)"><b>{{ \App\Support\Money::format($m->percentageProfit()) }}</b></td>
              </tr>
            @endforeach
          @endif

          {{-- Sub Bands --}}
          @if($subBands->isNotEmpty())
            <tr><td colspan="9" style="background:var(--bg);font-weight:600;font-size:0.85em;color:var(--text-muted);padding-right:20px;">البنود الفرعية</td></tr>
            @php $lastInvoiceId = null; @endphp
            @foreach($subBands as $m)
              @if($m->invoice_id && str_starts_with($m->invoice?->name ?? '', 'بند فرعي:'))
                @if($lastInvoiceId !== $m->invoice_id)
                  <tr style="background-color: var(--bg-hover);">
                    <td>{{ $m->date->format('Y-m-d') }}</td>
                    <td colspan="8" style="font-weight:bold; color:var(--accent);">
                      بند فرعي: {{ explode(' — ', str_replace('بند فرعي: ', '', $m->invoice->name))[0] }}
                    </td>
                  </tr>
                  @php $lastInvoiceId = $m->invoice_id; @endphp
                @endif
                <tr>
                  <td></td> {{-- Empty date cell for grouped items --}}
                  <td style="padding-right: 20px;">
                    <span style="color:var(--text-muted);margin-left:4px;">-</span> {{ $m->item }}
                    @if($m->notes)<br><small class="muted" style="font-size:12.5px;font-weight:500;">{{ $m->notes }}</small>@endif
                    @if($m->contract_type && $m->contract_type !== 'lump_sum') <br><small class="muted" style="font-size:11px">({{ $m->contractTypeAr() }})</small> @endif
                    @if($m->returnedQty() > 0)<span style="color:var(--neg);font-size:10.5px">(مرتجع {{ \App\Support\Money::format($m->returnedQty(), 1) }})</span>@endif
                  </td>
                  <td class="muted">{{ $m->supplier?->name ?? $m->supplier_name ?? '—' }}</td>
                  <td class="num">{{ ($m->contract_type === 'lump_sum') ? '—' : \App\Support\Money::format($m->netQty(), 1) . ' ' . $m->unit }}</td>
                  <td class="num">{{ ($m->contract_type === 'lump_sum') ? '—' : \App\Support\Money::format($m->unit_price) }}</td>
                  <td class="num"><b>{{ \App\Support\Money::format($m->netCost()) }}</b></td>
                  <td class="num">{{ \App\Support\Money::format($m->netQty() * (float)($m->sell_price ?? $m->unit_price)) }}</td>
                  <td class="num">{{ (float) $m->supervision_pct }}%</td>
                  <td class="num" style="color:var(--pos)"><b>{{ \App\Support\Money::format($m->percentageProfit()) }}</b></td>
                </tr>
              @else
                @php $lastInvoiceId = null; @endphp
                <tr>
                  <td>{{ $m->date->format('Y-m-d') }}</td>
                  <td>
                    {{ $m->item }}
                    @if($m->supplier_name && !$m->band_worker_id)<br><small class="muted" style="font-size:11px">{{ $m->supplier_name }}</small>@endif
                    @if($m->notes)<br><small class="muted" style="font-size:12.5px;font-weight:500;">{{ $m->notes }}</small>@endif
                    @if($m->contract_type && $m->contract_type !== 'lump_sum') <br><small class="muted" style="font-size:11px">({{ $m->contractTypeAr() }})</small> @endif
                    @if($m->returnedQty() > 0)<span style="color:var(--neg);font-size:10.5px">(مرتجع {{ \App\Support\Money::format($m->returnedQty(), 1) }})</span>@endif
                  </td>
                  <td class="muted">{{ $m->supplier?->name ?? $m->supplier_name ?? '—' }}</td>
                  <td class="num">{{ ($m->contract_type === 'lump_sum') ? '—' : \App\Support\Money::format($m->netQty(), 1) . ' ' . $m->unit }}</td>
                  <td class="num">{{ ($m->contract_type === 'lump_sum') ? '—' : \App\Support\Money::format($m->unit_price) }}</td>
                  <td class="num"><b>{{ \App\Support\Money::format($m->netCost()) }}</b></td>
                  <td class="num">{{ \App\Support\Money::format($m->netQty() * (float)($m->sell_price ?? $m->unit_price)) }}</td>
                  <td class="num">{{ (float) $m->supervision_pct }}%</td>
                  <td class="num" style="color:var(--pos)"><b>{{ \App\Support\Money::format($m->percentageProfit()) }}</b></td>
                </tr>
              @endif
            @endforeach
          @endif

          @if($band->materials->isEmpty())
            <tr><td colspan="9" class="muted" style="text-align:center;padding:12px">لا مشتريات لهذا البند</td></tr>
          @endif
          <tr class="sub">
            <td colspan="5" style="text-align:left">إجمالي تكلفة المشتريات</td>
            <td class="num">{{ \App\Support\Money::format($bMaterialCost) }} ج.م</td>
            <td colspan="3"></td>
          </tr>
        </tbody>
      </table>

      {{-- Labor / technicians --}}
      <table class="st-table" style="margin-top:8px">
        <thead><tr><th>الفني</th><th>التخصص</th><th>نوع التعاقد</th><th>بداية العمل</th><th class="num">الأجر (التكلفة)</th><th class="num">سعر البيع</th><th class="num">إشراف %</th><th class="num">إشراف (ج.م)</th></tr></thead>
        <tbody>
          @forelse($band->real_workers as $w)
            <tr>
              <td>{{ $w->name }}</td>
              <td class="muted">{{ $w->specialty ?: '—' }}</td>
              <td class="muted">{{ $w->contractTypeAr() }}
                @if(in_array($w->contract_type, ['per_meter', 'per_piece']) && $w->contract_qty > 0)
                  <br><small style="opacity:0.85">الكمية: {{ (float)$w->contract_qty }} {{ $w->contract_type === 'per_meter' ? 'متر' : 'قطعة' }}</small>
                @endif
              </td>
              <td class="muted">{{ $w->start_date?->format('Y-m-d') ?? '—' }}</td>
              <td class="num"><b>{{ \App\Support\Money::format($w->amount) }}</b></td>
              <td class="num">{{ \App\Support\Money::format((float) ($w->sell_amount ?: $w->amount)) }}</td>
              <td class="num">{{ (float) $w->supervision_pct }}%</td>
              <td class="num" style="color:var(--pos)"><b>{{ \App\Support\Money::format($w->percentageProfit()) }}</b></td>
            </tr>
          @empty
            @if($band->labor_amount > 0)
              <tr>
                <td>{{ $band->team_name ?: '—' }}</td>
                <td class="muted">—</td>
                <td class="muted">{{ $band->contract_type ? $band->contractTypeAr() : '—' }}</td>
                <td class="muted">—</td>
                <td class="num"><b>{{ \App\Support\Money::format($band->labor_amount) }}</b></td>
                <td class="num">{{ \App\Support\Money::format((float) ($band->labor_sell_price ?? $band->labor_amount)) }}</td>
                <td class="num">{{ (float) $band->labor_supervision_pct }}%</td>
                <td class="num" style="color:var(--pos)"><b>{{ \App\Support\Money::format(((float) ($band->labor_sell_price ?? $band->labor_amount)) * ((float) $band->labor_supervision_pct / 100)) }}</b></td>
              </tr>
            @else
              <tr><td colspan="8" class="muted" style="text-align:center;padding:12px">لا مصنعية لهذا البند</td></tr>
            @endif
          @endforelse
          <tr class="sub">
            <td colspan="4" style="text-align:left">إجمالي المصنعية</td>
            <td class="num">{{ \App\Support\Money::format($bLaborCost) }} ج.م</td>
            <td colspan="3"></td>
          </tr>
        </tbody>
      </table>
    @endforeach

    {{-- Final project summary --}}
    <div class="st-final">
      <table>
        <tr><td class="muted">إجمالي تكلفة المشروع (مشتريات + مصنعية)</td><td style="text-align:left;font-weight:700">{{ \App\Support\Money::format($totalCost) }} ج.م</td></tr>
        <tr><td class="muted">المفوتر على العميل</td><td style="text-align:left;font-weight:700">{{ \App\Support\Money::format($totalBilled) }} ج.م</td></tr>
        <tr><td class="muted">المحصّل من العميل</td><td style="text-align:left;font-weight:700">{{ \App\Support\Money::format($totalCollected) }} ج.م</td></tr>
        @php
          $totalDisc = $project->totalDiscount();
          $marketersCommission = (float) $project->transactions()->where('ref_type', 'marketer_commission')->sum('amount');
          $projectExpenses = (float) $project->transactions()->where('ref_type', 'project_expense')->sum('amount');
        @endphp
        <tr><td class="muted" style="color:var(--amber)">الخصومات الممنوحة للعميل</td><td style="text-align:left;font-weight:700;color:var(--amber)">{{ $totalDisc > 0 ? '-' : '' }}{{ \App\Support\Money::format($totalDisc) }} ج.م</td></tr>
        <tr><td class="muted" style="color:var(--neg)">عمولة المسوقين</td><td style="text-align:left;font-weight:700;color:var(--neg)">{{ $marketersCommission > 0 ? '-' : '' }}{{ \App\Support\Money::format($marketersCommission) }} ج.م</td></tr>
        <tr><td class="muted" style="color:var(--neg)">المصروفات العامة للمشروع</td><td style="text-align:left;font-weight:700;color:var(--neg)">{{ $projectExpenses > 0 ? '-' : '' }}{{ \App\Support\Money::format($projectExpenses) }} ج.م</td></tr>
        <tr class="big"><td>صافي الربح</td><td style="text-align:left">{{ \App\Support\Money::format($totalProfit) }} ج.م</td></tr>
      </table>
    </div>
  </div>

  <div class="st-foot">
    <span>كشف داخلي — لا يُشارك مع العميل.</span>
    <span>توقيع: ____________</span>
  </div>
</div>
@endsection
